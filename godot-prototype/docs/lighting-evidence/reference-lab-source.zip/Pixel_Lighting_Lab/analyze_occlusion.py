"""Read actual full-frame PNGs, compare cyan visibility with independent box rays.
Requires Pillow. It never writes or modifies an image.
"""
import argparse
import json
import math
from pathlib import Path
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument('run_directory', type=Path)
args = parser.parse_args()
folder = args.run_directory
report = json.loads((folder / 'occlusion_report.json').read_text())
root = folder.parent.parent
art = Image.open(root / 'generated/occlusion_actor.png').convert('RGBA')
boxes = [((-1.65, 1.35, 0), (.7, 2.7, .64)), ((-.025, 2.6, 0), (2.55, .4, .72)), ((1.65, 1.525, 0), (.8, 3.05, .64))]
right = (1 / math.sqrt(2), 0, -1 / math.sqrt(2))
up = (-1 / math.sqrt(6), 2 / math.sqrt(6), -1 / math.sqrt(6))
target = (0, 1.15, 0)

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def hidden(point, margin=0):
    for center, size in boxes:
        near = max([0.0001] + [(center[i] - size[i]/2 - margin - point[i]) * math.sqrt(3) for i in range(3)])
        far = min((center[i] + size[i]/2 + margin - point[i]) * math.sqrt(3) for i in range(3))
        if near <= far:
            return True
    return False

def evaluate(frame):
    image = Image.open(folder / frame['file']).convert('RGB')
    position = frame['position']
    scores = [{'samples': 0, 'errors': 0} for _ in range(3)]
    boundary = 0
    for y in range(24):
        for x in range(16):
            if art.getpixel((x, y))[3] < 128:
                continue
            lateral = ((x+.5)/16-.5) * .72
            height = (1-(y+.5)/24) * 1.08
            point = tuple(position[i] + right[i]*lateral + (height if i == 1 else 0) for i in range(3))
            if hidden(point, .025) != hidden(point, -.025):
                boundary += 1
                continue
            relative = tuple(point[i]-target[i] for i in range(3))
            sx = math.floor(75 + dot(relative, right)*220/6.8)
            sy = math.floor(110 - dot(relative, up)*220/6.8)
            if not (0 <= sx < 150 and 0 <= sy < 220):
                continue
            should_show = not hidden(point)
            for i in range(3):
                r, g, b = image.getpixel((10+320*i+2*sx+1, 106+2*sy+1))
                visible = g > r+.12*255 and b > r+.12*255
                scores[i]['samples'] += 1
                scores[i]['errors'] += visible != should_show
    return {'file':frame['file'], 'position':position, 'seconds':frame.get('seconds'), 'scores_ABC':scores, 'boundary_excluded':boundary}

static = [evaluate({'file':x['name']+'_full.png', 'position':x['position']}) for x in report['checkpoints']]
moving = [evaluate(x) for x in report['motion']]
def totals(rows):
    return [{'samples':sum(r['scores_ABC'][i]['samples'] for r in rows), 'errors':sum(r['scores_ABC'][i]['errors'] for r in rows)} for i in range(3)]
result = {'static':static, 'static_totals_ABC':totals(static), 'motion':moving, 'motion_totals_ABC':totals(moving), 'scope':'Pixel-center samples, silhouette boundary margin .025 world units. A/B are flat compositing rules; C uses real depth. This is not an all-camera guarantee.'}
(folder / 'independent_pixel_validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'static_totals_ABC':result['static_totals_ABC'], 'motion_totals_ABC':result['motion_totals_ABC'], 'motion_frames':len(moving)},indent=2))
