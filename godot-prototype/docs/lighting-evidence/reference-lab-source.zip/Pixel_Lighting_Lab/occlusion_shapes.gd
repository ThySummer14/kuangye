extends Node2D
# One grouped CanvasItem drawing either the whole arch or one separated part.
var faces: Array[Dictionary] = []
func _draw() -> void:
	for face in faces:
		draw_colored_polygon(face.points, face.color)
