extends Node
# Original fixed-camera experiment. B sorts independent supports by their own
# ground anchors, and keeps the overhead beam in an explicit foreground layer.
# No rule reads a path index or the output of the 3D reference renderer.

const VW := 150
const VH := 220
const WORLD_SIZE := 6.8
const TARGET := Vector3(0, 1.15, 0)
const ACTOR_SIZE := Vector2(0.72, 1.08)
const RIGHT := Vector3(0.70710678, 0, -0.70710678)
const VIEW_UP := Vector3(-0.40824829, 0.81649658, -0.40824829)
const TO_CAMERA := Vector3(0.57735027, 0.57735027, 0.57735027)
const BOXES := [
	{"name": "left_support", "center": Vector3(-1.65, 1.35, 0), "size": Vector3(0.7, 2.7, 0.64), "color": Color(0.48, 0.32, 0.21)},
	{"name": "beam", "center": Vector3(-0.025, 2.6, 0), "size": Vector3(2.55, 0.4, 0.72), "color": Color(0.7, 0.5, 0.29)},
	{"name": "right_support", "center": Vector3(1.65, 1.525, 0), "size": Vector3(0.8, 3.05, 0.64), "color": Color(0.58, 0.39, 0.26)}
]
const CHECKPOINTS := [
	{"name": "rear_beam", "pos": Vector3(-1.55, 0, -1.55)},
	{"name": "left_front", "pos": Vector3(-1.55, 0, 0.85)},
	{"name": "opening", "pos": Vector3(0, 0, 0.15)},
	{"name": "right_rear", "pos": Vector3(0.7, 0, -0.3)},
	{"name": "right_front", "pos": Vector3(1.65, 0, 0.85)}
]
const ROUTE := [Vector3(-1.55, 0, -1.55), Vector3(-2.5, 0, -0.9), Vector3(-2.5, 0, 0.85), Vector3(-1.55, 0, 0.85), Vector3(0, 0, 0.15), Vector3(0.7, 0, -0.3), Vector3(2.5, 0, -0.8), Vector3(2.5, 0, 0.85), Vector3(1.65, 0, 0.85)]

var views: Array[SubViewport] = []
var canvas_actors: Array[Node2D] = []
var actor_3d: MeshInstance3D
var camera: Camera3D
var sprite_image: Image
var sprite_texture: ImageTexture
var actor_position := Vector3.ZERO
var stage_label: Label
var summaries: Array[Dictionary] = []
var motion: Array[Dictionary] = []
var out := ""
var auto_play := true
var elapsed := 0.0

func project(point: Vector3) -> Vector2:
	var delta := point - TARGET
	var scale := float(VH) / WORLD_SIZE
	return Vector2(VW * 0.5 + delta.dot(RIGHT) * scale, VH * 0.5 - delta.dot(VIEW_UP) * scale)

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().unresizable = true
	get_window().size = Vector2i(960, 640)
	make_actor_art()
	build_ui()
	build_2d(0, false)
	build_2d(1, true)
	build_3d()
	set_position(CHECKPOINTS[0].pos)
	if OS.get_cmdline_user_args().has("--probe-occlusion"):
		auto_play = false
		call_deferred("run_probe")

func make_actor_art() -> void:
	sprite_image = Image.create(16, 24, false, Image.FORMAT_RGBA8)
	for y in range(24):
		for x in range(16):
			var head := x >= 5 and x <= 10 and y >= 1 and y <= 7
			var torso := x >= 4 and x <= 11 and y >= 8 and y <= 17
			var arms := x >= 2 and x <= 13 and y >= 10 and y <= 14
			var legs := ((x >= 4 and x <= 6) or (x >= 9 and x <= 11)) and y >= 18 and y <= 22
			if head or torso or arms or legs:
				var c := Color("38d5e8")
				if (x + y) % 7 == 0 or y == 22:
					c = Color("168496")
				if head and y == 4 and (x == 6 or x == 9):
					c = Color("0c606d")
				sprite_image.set_pixel(x, y, c)
	sprite_texture = ImageTexture.create_from_image(sprite_image)
	DirAccess.make_dir_recursive_absolute("res://generated")
	sprite_image.save_png("res://generated/occlusion_actor.png")

func label(text: String, pos: Vector2, size: int, parent: Node) -> Label:
	var item := Label.new()
	item.text = text
	item.position = pos
	item.add_theme_font_size_override("font_size", size)
	item.add_theme_color_override("font_color", Color("dce6df"))
	parent.add_child(item)
	return item

func build_ui() -> void:
	var ui := Control.new()
	add_child(ui)
	var bg := ColorRect.new()
	bg.size = Vector2(960, 640)
	bg.color = Color("101922")
	ui.add_child(bg)
	label("ONE ARCH, THREE OCCLUSION METHODS", Vector2(18, 8), 22, ui)
	stage_label = label("", Vector2(18, 38), 16, ui)
	var titles := ["A  ONE Y-SORT GROUP", "B  SPLIT SUPPORTS + BEAM", "C  ACTUAL 3D DEPTH"]
	for i in range(3):
		label(titles[i], Vector2(14 + 320 * i, 79), 16, ui)
		var view := SubViewport.new()
		view.size = Vector2i(VW, VH)
		view.own_world_3d = true
		view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		view.msaa_3d = Viewport.MSAA_DISABLED
		add_child(view)
		views.append(view)
		var image_view := TextureRect.new()
		image_view.texture = view.get_texture()
		image_view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		image_view.position = Vector2(10 + i * 320, 106)
		image_view.size = Vector2(VW * 2, VH * 2)
		ui.add_child(image_view)
	label("Same world path, actor size and orthographic projection. Cyan pixels = actor.", Vector2(18, 565), 17, ui)
	label("Space pause / play   |   1-5 checkpoints   |   6 held-out midpoint", Vector2(18, 598), 16, ui)

func projected_faces(box: Dictionary, anchor: Vector2) -> Array[Dictionary]:
	var c: Vector3 = box.center
	var h: Vector3 = box.size * 0.5
	var faces: Array[Dictionary] = []
	var sets := [
		[Vector3(-1,-1,1),Vector3(1,-1,1),Vector3(1,1,1),Vector3(-1,1,1)],
		[Vector3(1,-1,1),Vector3(1,-1,-1),Vector3(1,1,-1),Vector3(1,1,1)],
		[Vector3(-1,1,1),Vector3(1,1,1),Vector3(1,1,-1),Vector3(-1,1,-1)]
	]
	for i in range(3):
		var points := PackedVector2Array()
		for corner in sets[i]:
			points.append(project(c + corner * h) - anchor)
		var color: Color = box.color * [0.86, 0.67, 1.12][i]
		color.a = 1.0
		faces.append({"points": points, "color": color})
	return faces

func canvas_part(parent: Node2D, boxes: Array, anchor_world: Vector3, foreground: bool = false) -> Node2D:
	var part: Node2D = load("res://occlusion_shapes.gd").new()
	part.position = project(anchor_world)
	part.y_sort_enabled = false
	part.z_index = 1 if foreground else 0
	for box_data in boxes:
		part.faces.append_array(projected_faces(box_data, part.position))
	parent.add_child(part)
	return part

func build_2d(index: int, split: bool) -> void:
	var base := Node2D.new()
	views[index].add_child(base)
	var backdrop := ColorRect.new()
	backdrop.size = Vector2(VW, VH)
	backdrop.color = Color("182630")
	base.add_child(backdrop)
	var floor := Polygon2D.new()
	floor.polygon = PackedVector2Array([project(Vector3(-3.5,0,-2.6)), project(Vector3(3.5,0,-2.6)), project(Vector3(3.5,0,2.6)), project(Vector3(-3.5,0,2.6))])
	floor.color = Color("374346")
	base.add_child(floor)
	var sorted := Node2D.new()
	sorted.y_sort_enabled = true
	base.add_child(sorted)
	if split:
		# General authored rule: each vertical support uses its own foot anchor.
		# The overhead beam remains foreground for this ground-only, short actor.
		canvas_part(sorted, [BOXES[0]], Vector3(BOXES[0].center.x, 0, BOXES[0].center.z))
		canvas_part(sorted, [BOXES[2]], Vector3(BOXES[2].center.x, 0, BOXES[2].center.z))
		canvas_part(sorted, [BOXES[1]], Vector3(BOXES[1].center.x, 0, BOXES[1].center.z), true)
	else:
		canvas_part(sorted, BOXES, Vector3.ZERO)
	var feet := Node2D.new()
	sorted.add_child(feet)
	var sprite := Sprite2D.new()
	sprite.texture = sprite_texture
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.centered = false
	var size_pixels := Vector2(ACTOR_SIZE.x, ACTOR_SIZE.y * VIEW_UP.y) * float(VH) / WORLD_SIZE
	sprite.position = Vector2(-size_pixels.x * 0.5, -size_pixels.y)
	sprite.scale = size_pixels / Vector2(16, 24)
	feet.add_child(sprite)
	canvas_actors.append(feet)

func unlit(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = color
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return material

func build_3d() -> void:
	var world := Node3D.new()
	views[2].add_child(world)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("182630")
	world.add_child(environment)
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.size = WORLD_SIZE
	camera.far = 40
	camera.position = TARGET + Vector3(8,8,8)
	world.add_child(camera)
	camera.look_at(TARGET)
	camera.current = true
	var plane := PlaneMesh.new()
	plane.size = Vector2(7,5.2)
	var floor := MeshInstance3D.new()
	floor.mesh = plane
	floor.material_override = unlit(Color("374346"))
	floor.position.y = -0.001
	world.add_child(floor)
	for box_data in BOXES:
		var mesh := BoxMesh.new()
		mesh.size = box_data.size
		var node := MeshInstance3D.new()
		node.mesh = mesh
		node.position = box_data.center
		node.material_override = unlit(box_data.color)
		world.add_child(node)
	actor_3d = MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = ACTOR_SIZE
	actor_3d.mesh = quad
	actor_3d.rotation.y = PI * 0.25
	var material := ShaderMaterial.new()
	material.shader = load("res://occlusion_actor.gdshader")
	material.set_shader_parameter("sprite", sprite_texture)
	actor_3d.material_override = material
	world.add_child(actor_3d)

func set_position(point: Vector3) -> void:
	actor_position = point
	for actor in canvas_actors:
		actor.position = project(point)
	actor_3d.position = point + Vector3.UP * ACTOR_SIZE.y * 0.5
	stage_label.text = "Ground (x,z) = (%.3f, %.3f)   |   character %.2f x %.2f world units" % [point.x, point.z, ACTOR_SIZE.x, ACTOR_SIZE.y]

func _process(delta: float) -> void:
	if auto_play:
		elapsed += delta
		var phase := fmod(elapsed / 1.4, float(ROUTE.size() - 1))
		var index := int(phase)
		set_position(ROUTE[index].lerp(ROUTE[index + 1], phase - index))

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo() or not event is InputEventKey:
		return
	if event.keycode == KEY_SPACE:
		auto_play = not auto_play
	elif event.keycode >= KEY_1 and event.keycode <= KEY_5:
		auto_play = false
		set_position(CHECKPOINTS[event.keycode - KEY_1].pos)
	elif event.keycode == KEY_6:
		auto_play = false
		set_position(ROUTE[5].lerp(ROUTE[6], 0.5))

func point_occluded(point: Vector3, margin: float = 0.0) -> bool:
	for box_data in BOXES:
		var minimum: Vector3 = box_data.center - box_data.size * 0.5 - Vector3.ONE * margin
		var maximum: Vector3 = box_data.center + box_data.size * 0.5 + Vector3.ONE * margin
		var start := 0.0001
		var stop := 100.0
		for axis in range(3):
			start = maxf(start, (minimum[axis] - point[axis]) / TO_CAMERA[axis])
			stop = minf(stop, (maximum[axis] - point[axis]) / TO_CAMERA[axis])
		if start <= stop:
			return true
	return false

func cyan(color: Color) -> bool:
	return color.g > color.r + 0.12 and color.b > color.r + 0.12

func evaluate(images: Array[Image]) -> Dictionary:
	var rows: Array[Dictionary] = []
	var mask := Image.create(VW, VH, false, Image.FORMAT_RGBA8)
	var scores := [{"visible_expected":0,"hidden_expected":0,"matches":0,"errors":0},{"visible_expected":0,"hidden_expected":0,"matches":0,"errors":0},{"visible_expected":0,"hidden_expected":0,"matches":0,"errors":0}]
	var excluded := 0
	for y in range(24):
		for x in range(16):
			if sprite_image.get_pixel(x,y).a < 0.5:
				continue
			var point := actor_position + RIGHT * ((float(x)+0.5)/16.0-0.5) * ACTOR_SIZE.x + Vector3.UP * (1.0-(float(y)+0.5)/24.0) * ACTOR_SIZE.y
			# Exclude ray/box silhouettes within 0.025 world units: raster edge ambiguity.
			var hidden := point_occluded(point)
			if point_occluded(point,0.025) != point_occluded(point,-0.025):
				excluded += 1
				continue
			var pixel := Vector2i(project(point).floor())
			if pixel.x < 0 or pixel.y < 0 or pixel.x >= VW or pixel.y >= VH:
				continue
			mask.set_pixelv(pixel, Color.RED if hidden else Color.GREEN)
			var visible_actual: Array[bool] = []
			for i in range(3):
				var visible := cyan(images[i].get_pixelv(pixel))
				visible_actual.append(visible)
				scores[i]["hidden_expected" if hidden else "visible_expected"] += 1
				scores[i]["matches" if visible != hidden else "errors"] += 1
			rows.append({"texel":[x,y],"pixel":[pixel.x,pixel.y],"expected_visible":not hidden,"actual_visible_ABC":visible_actual})
	return {"scores_ABC":scores,"excluded_boundary_texels":excluded,"samples":rows,"mask":mask}

func settle(frames: int = 5) -> void:
	for i in range(frames):
		await get_tree().process_frame

func capture(name: String, point: Vector3, held_out: bool) -> void:
	set_position(point)
	await settle()
	await RenderingServer.frame_post_draw
	var images: Array[Image] = []
	for i in range(3):
		var image := views[i].get_texture().get_image()
		image.save_png(out+name+"_"+["A","B","C"][i]+".png")
		images.append(image)
	get_viewport().get_texture().get_image().save_png(out+name+"_full.png")
	var evaluation := evaluate(images)
	var mask: Image = evaluation.mask
	mask.save_png(out+name+"_expected_mask.png")
	evaluation.erase("mask")
	evaluation.merge({"name":name,"position":[point.x,point.y,point.z],"held_out_midpoint":held_out,"time_usec":Time.get_ticks_usec(),"projection_delta_pixels":project(point).distance_to(camera.unproject_position(point))})
	summaries.append(evaluation)

func run_probe() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Occlusion screenshots require the real renderer.")
		get_tree().quit(2)
		return
	out = "res://qa/occlusion_"+str(int(Time.get_unix_time_from_system()))+"/"
	DirAccess.make_dir_recursive_absolute(out)
	await settle(10)
	for i in range(CHECKPOINTS.size()):
		await capture("%02d_%s" % [i,CHECKPOINTS[i].name],CHECKPOINTS[i].pos,false)
	await capture("05_held_out_midpoint",ROUTE[5].lerp(ROUTE[6],0.5),true)
	# Actual-time path samples, never synthesized or interpolated PNG frames.
	var start := Time.get_ticks_usec()
	var next_frame := 0.0
	while Time.get_ticks_usec()-start < 8000000:
		await get_tree().process_frame
		var seconds := float(Time.get_ticks_usec()-start)/1000000.0
		var phase := minf(seconds,float(ROUTE.size()-1)-0.0001)
		var index := int(phase)
		set_position(ROUTE[index].lerp(ROUTE[index+1],phase-index))
		if seconds >= next_frame:
			await RenderingServer.frame_post_draw
			var name := "motion_%03d.png" % motion.size()
			get_viewport().get_texture().get_image().save_png(out+name)
			motion.append({"file":name,"seconds":seconds,"position":[actor_position.x,actor_position.y,actor_position.z]})
			next_frame = seconds+0.33
	var report := {"engine":Engine.get_version_info().string,"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"viewport":[VW,VH],"window":[get_window().size.x,get_window().size.y],"actor_size_world_units":[ACTOR_SIZE.x,ACTOR_SIZE.y],"camera_position":[camera.position.x,camera.position.y,camera.position.z],"camera_target":[TARGET.x,TARGET.y,TARGET.z],"camera_size":camera.size,"checkpoints":summaries,"motion":motion,"source_sha256":FileAccess.get_sha256("res://occlusion_lab.gd"),"B_rule":"Each support Y-sorts at its own ground center; beam is foreground. No checkpoint-specific rule.","reference":"Independent orthographic rays against authored box volumes; silhouette-near texels excluded. Native 3D renderer checked against same reference."}
	var file := FileAccess.open(out+"occlusion_report.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  "))
	print("OCCLUSION_PROBE_COMPLETE ",out)
	get_tree().quit()
