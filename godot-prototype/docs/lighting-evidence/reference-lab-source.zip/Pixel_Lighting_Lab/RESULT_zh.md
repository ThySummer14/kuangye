# 像素精灵法线与清晰阴影的实际实验

2026 年 10 月 8 日。目标为暮邮谷与旷野的 2.5D 像素材质研究。此轮完成一个独立、可运行的 Godot 工程；没有修改或发布两款游戏。

## 已得到的结果

同一张原创 24×32 镂空邮牌，能够在 Godot 4.6.3 Compatibility 中展示正确的切线法线受光、故意翻绿通道的错误、二值 alpha 裁剪、牌面接收挡杆阴影，以及牌向地面投影。另有独立的 CanvasTexture 2D 页，实际比较灯高 0 与 80 像素。

法线让牌面看起来鼓起，但它依然是一张平面。法线不增加实体厚度、碰撞或轮廓几何，也不让微小凹凸自动改变地面投影。最终相同地面区域的“平法线”和“正确法线”图逐像素一致；关闭 alpha 裁剪时，这个区域的 1,107 个像素改变。区分材质受光与遮挡形状，是这次实验最直接的结论。

推荐先把这套流程用于暮邮谷的邮牌、桥边小道具，以及旷野的少量室内手作摆件。法线应轻用；不要因示例有效就批量给所有像素画加浮雕。

## 实际运行与预算

| 项目 | 实测或固定值 |
| --- | --- |
| 引擎 | Godot 4.6.3-stable official，启动日志标识 7d41c59c4 |
| Renderer | 原生 gl_compatibility，OpenGL 4.5 |
| 图形设备 | Mesa llvmpipe LLVM 19.1.7 软件渲染 |
| 最终窗口图 | 真正输出的 960×640 PNG |
| 内部视图 | 480×272，nearest 放大两倍 |
| 相机 | 正交；位置约 (5.3, 5.1, 8.8)，观察 (0, 1.1, 0)，size 5.2 世界单位，far 30 |
| 3D 主灯 | DirectionalLight3D，位置 (-3, 5, 4) 指向原点；位置用于确定方向，不是点光衰减距离 |
| 局部灯 | OmniLight3D，位置 (2.3, 1.8, 2.3)，range 5.5 世界单位，energy 0.85；只改暖/冷颜色 |
| 2D 灯 | PointLight2D，位置 (160, 72) canvas 像素；height 比较 0 / 80 像素；sprite scale 6 |
| 最终阴影组合 | 1024 阴影图，单级正交阴影，shadow_bias 0.1，shadow_normal_bias 2.0，固定低档滤波 quality 1，阴影距离 30 |
| 最终运行 | 12.553 秒，峰值 RSS 211,236 KiB，约 206.3 MiB，exit 0 |
| 全部原生运行累计 | 45.540 秒；未触发 110 秒总预算或 1 GiB 内存上限 |

这些数据证明云端这台机器上的实际运行。没有浏览器 WebGL2 实测，也不据此推算手机帧率。驱动还提示不能改变 V-Sync；帧时间受软件渲染、调度与显示行为影响。[Godot Web 导出要求](https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_web.html)

最终四段 A/B/A/B 各约 2.5 秒，依次为平法线、正确法线、平法线、正确法线。中位帧时间为 10.130、10.242、10.587、10.242 ms；P95 为 14.805、13.899、15.969、14.071 ms，每段记录 12 次 draw call。样本短，使用同一 shader 的 uniform 分支，不能据这个差异断言法线成本为零或更快。它只是当前测试房的运行记录。

## 怎么读最终图

最终取证位于 qa/run_1791464804，每张完整窗口图都有同名 _view.png 原始内部视图。文件没有经过图像生成、修图、锐化或补画。

| 文件 | 控制变量与观察 |
| --- | --- |
| 01_flat.png / 02_correct_normal.png | 底色、几何、灯和相机相同；正确法线增加表面明暗起伏，轮廓与地面投影保持相同 |
| 03_wrong_green.png | 只翻绿通道；上半部凸起方向与正确样本明显不符，是故意设置的负例 |
| 04_no_alpha_clip.png | alpha 裁剪关闭；镂空和切角变成完整矩形，地面投影也随之改变 |
| 05_no_shadow.png | 主灯阴影关闭；投影消失，但此渲染路径的整体受光也改变，因此不把它当纯阴影成本或光能对照 |
| 06_cool_local_light.png | 局部灯从暖色改为冷色，位置与能量固定，辨认灯色对材质色的影响 |
| 07_without_blocker.png | 移除真实挡杆；牌面斜阴影消失。在排除挡杆自身几何的牌面区域，有 1,261 个像素改变 |
| 08_static_repeat.png | 恢复同一静态状态；内部视图与 02 逐像素完全一致，最大通道差为 0 |
| 09_canvas_height_0.png / 10_canvas_height_80.png | 只改 PointLight2D 的虚拟受光高度；材质亮部变化，图片形状、厚度、遮挡并未变成 3D |
| 11_canvas_flat_height_80.png | 2D 平法线参照，用来区分普通灯衰减与法线带来的局部变化 |

像素比较在 pixel_validation.json 和 spatial_validation.json 中保留。静态重复一致不代表移动相机时没有跳动；这轮没有验证滚屏、四分之一像素相机运动或整套角色动画。所有对照仍需要配合真实图观察，不能只凭“有像素变化”判成功。

## 保留的失败和调整

首次 headless 检查虽然进程 exit 0，日志仍有不存在的 Environment 枚举和缓存路径错误。修复枚举、使用实验目录内缓存后，独立语法复查通过。没有把第一次退出码当成程序正确。

第一轮原生运行 16.844 秒。窗口管理器把所请求的 960×640 扩成 1178×785，内部视图仍为 480×272；并出现明显的三角状自阴影伪影。原先 metadata 写的是请求尺寸，已经追加实测尺寸和未通过原因。

第二轮 14.586 秒固定了真正窗口尺寸，改为单一地面网格、单级阴影等设置。牌面格纹减轻，但投影过弱，仍未算清晰阴影验收通过。

随后用 1.557 秒做六档 shadow_bias 扫描。相机 far 与阴影距离统一为 30；六档共享灯方向、对象比例、相机、normal bias 0.1 和 1024 阴影分辨率。真实地面和挡杆投影可见，但牌面仍有格纹；六张内部图完全相同。这说明本轮捕捉没有提供 bias 改动有效的证据，不能据它画出一条“bias 越高越好”的曲线，也不足以单独确定是缓存、精度还是 renderer 行为。

最终组合使用 normal bias 2.0、固定低档滤波和受控相机/阴影范围，牌面格纹消失，镂空投影与挡杆斜投影清楚。这个结论来自组合调整后的实际图，不能归因成单一参数的因果证明。此前两轮及扫描图、日志、参数仍保留在 qa 与 evidence 中。Godot 官方也指出，偏置过小可能自阴影，过大可能造成投影脱离；具体折衷必须结合场景尺度检查。[Light3D 阴影参数](https://docs.godotengine.org/en/4.6/classes/class_light3d.html)

## 对两款游戏可迁移的做法

1. 3D 世界中的像素牌、薄叶片和人物卡片，用 3D 材质的切线法线、真实深度与必要的 alpha 裁剪。预渲染 sprite 的底色和 normal 必须逐帧对齐，先避免底色里烘入强固定主灯，减少双重明暗。法线不能替代厚度或遮挡代理。
2. 纯 2D 页面继续用 CanvasTexture 与 PointLight2D；灯高按 canvas 像素与图像尺寸调，不把 80 或教程里的 120–200 当通用常量。CanvasTexture 不能直接用于 Sprite3D。[CanvasTexture](https://docs.godotengine.org/en/4.6/classes/class_canvastexture.html) · [PointLight2D](https://docs.godotengine.org/en/4.6/classes/class_pointlight2d.html)
3. 开发前先固定分辨率、nearest 采样、颜色空间与相机，再校正法线的 Y 方向。Godot NORMAL_MAP 接收切线空间编码，常规约定为 OpenGL +X/+Y/+Z；本实验把图像向下的行号显式转换为向上的表面导数。[Spatial shader](https://docs.godotengine.org/en/4.6/tutorials/shaders/shader_reference/spatial_shader.html) · [StandardMaterial3D](https://docs.godotengine.org/en/4.6/tutorials/3d/standard_material_3d.html)
4. 使用稳定的固定采样，先证明静态重复一致，再测移动。Minecraft shader 中依赖 TAA 的逐帧随机旋转不能直接放进没有历史积累的路径。Godot Compatibility 的功能边界要按当前文档逐项确认，不能把其他 renderer 的 PCSS、TAA 或内置 SSR 直接默认可用。[Renderer 对照](https://docs.godotengine.org/en/4.6/tutorials/rendering/renderers.html)
5. 水面下一步仍优先把同一岸线权重用于扭曲衰减与泡沫反射衰减；深度/材质判定失败时回退。它们来自已核 Minecraft 包的算法观察，尚未在这个邮牌实验里实现。新增屏幕读取、深度重建或额外 pass 时单独计预算，不与本实验的低成本法线结论混算。

## 可运行备份与许可

工程包含 project.godot、main.tscn、lab.gd、两个原创 shader、原始生成的 diffuse/normal/height 图、运行说明、全部取证图与 JSON。解压后用 Godot 4.6 打开即可运行。可选 Python 图像验证依赖 Pillow，不影响 Godot 工程运行。

原创工程和素材使用 MIT 许可，见 LICENSE.txt。没有打包 Complementary、Photon、MakeUp、Minecraft、HMCL 或其他外部项目源码/二进制。研究这些包的许可仍各自有效，不能因为本实验采用 MIT 就把原包代码纳入该许可。没有新登录、接受 Minecraft EULA、运行 mod 或启动 Minecraft。

这份备份可供后续项目 docs 引用。迁入实际游戏前，还应选一件真实物品检查原贴图、尺寸、遮挡和相机移动，并在目标浏览器补 WebGL2 验收；本次没有声称这些工作已完成。
