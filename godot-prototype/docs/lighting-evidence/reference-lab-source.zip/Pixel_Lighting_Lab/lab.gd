extends Node
# All artwork, height field, scene and shader are original to this experiment.
# This is a fixed quad with tangent-space detail, not geometric displacement.

var viewport: SubViewport
var world: Node3D
var canvas: Node2D
var camera: Camera3D
var key_light: DirectionalLight3D
var fill_light: OmniLight3D
var card: MeshInstance3D
var blocker: MeshInstance3D
var material: ShaderMaterial
var light_2d: PointLight2D
var sprite_2d: Sprite2D
var canvas_texture: CanvasTexture
var diffuse: ImageTexture
var normals: ImageTexture
var flat_normals: ImageTexture
var heading: Label
var detail: Label
var footer: Label
var normal_mode := 1
var clip_alpha := true
var shadows := true
var warm := true
var page_2d := false
var lamp_height := 80.0
var captures: Array[Dictionary] = []
var measurements: Array[Dictionary] = []
var out := ""

func _ready() -> void:
	get_window().mode = Window.MODE_WINDOWED
	get_window().unresizable = true
	get_window().size = Vector2i(960, 640)
	make_textures()
	build_view()
	build_world()
	build_canvas()
	apply_state()
	if OS.get_cmdline_user_args().has("--probe"):
		call_deferred("run_probe")

func height_at(x: int, y: int) -> float:
	# Image y runs down; the constructed surface uses +y up.
	var px := float(x) - 11.5
	var py := 15.5 - float(y)
	var dome := 2.4 * maxf(0.0, 1.0 - px * px / 96.0 - py * py / 160.0)
	var ridge := 1.3 * maxf(0.0, 1.0 - absf(py - 5.5) / 2.8) * maxf(0.0, 1.0 - absf(px) / 10.0)
	return dome + ridge

func make_textures() -> void:
	var color := Image.create(24, 32, false, Image.FORMAT_RGBA8)
	var normal := Image.create(24, 32, false, Image.FORMAT_RGBA8)
	var flat := Image.create(24, 32, false, Image.FORMAT_RGBA8)
	var height_image := Image.create(24, 32, false, Image.FORMAT_RGBA8)
	for y in range(32):
		for x in range(24):
			var cut_corner := (x < 4 or x > 19) and (y < 4 or y > 27)
			var inside := x >= 2 and x <= 21 and y >= 2 and y <= 29 and not cut_corner
			var hole := x >= 9 and x <= 14 and y >= 4 and y <= 7
			var edge := x < 4 or x > 19 or y < 4 or y > 27
			var c := Color("839b91") if edge else Color("b8c9b4")
			# A small envelope glyph. Its pigment is independent of surface height.
			if x >= 6 and x <= 17 and y >= 15 and y <= 23:
				c = Color("536e79")
				if y == 15 or y == 23 or x == 6 or x == 17 or y - 15 == mini(x - 6, 17 - x):
					c = Color("e2d09e")
			c.a = 1.0 if inside and not hole else 0.0
			color.set_pixel(x, y, c)
			var dx := (height_at(x + 1, y) - height_at(x - 1, y)) * 0.5
			var dy_up := (height_at(x, y - 1) - height_at(x, y + 1)) * 0.5
			var n := Vector3(-dx, -dy_up, 1.0).normalized()
			normal.set_pixel(x, y, Color(n.x * 0.5 + 0.5, n.y * 0.5 + 0.5, n.z * 0.5 + 0.5, 1.0))
			flat.set_pixel(x, y, Color(0.5, 0.5, 1.0, 1.0))
			var h := height_at(x, y) / 4.0
			height_image.set_pixel(x, y, Color(h, h, h, 1.0))
	diffuse = ImageTexture.create_from_image(color)
	normals = ImageTexture.create_from_image(normal)
	flat_normals = ImageTexture.create_from_image(flat)
	DirAccess.make_dir_recursive_absolute("res://generated")
	color.save_png("res://generated/card_diffuse.png")
	normal.save_png("res://generated/card_normal_opengl.png")
	height_image.save_png("res://generated/card_height_authoring.png")

func label_at(text: String, p: Vector2, font_size: int, parent: Node) -> Label:
	var label := Label.new()
	label.text = text
	label.position = p
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("dce6df"))
	parent.add_child(label)
	return label

func build_view() -> void:
	viewport = SubViewport.new()
	viewport.size = Vector2i(480, 272)
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.msaa_3d = Viewport.MSAA_DISABLED
	viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	add_child(viewport)
	var ui := Control.new()
	add_child(ui)
	var bg := ColorRect.new()
	bg.size = Vector2(960, 640)
	bg.color = Color("101922")
	ui.add_child(bg)
	var view := TextureRect.new()
	view.position = Vector2(0, 60)
	view.size = Vector2(960, 544)
	view.texture = viewport.get_texture()
	view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ui.add_child(view)
	heading = label_at("", Vector2(18, 6), 21, ui)
	detail = label_at("", Vector2(18, 34), 14, ui)
	footer = label_at("1 3D  |  2 Canvas  |  N normal  |  C clip  |  S shadow  |  L color  |  H height", Vector2(18, 613), 15, ui)

func matte(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	mat.metallic_specular = 0.0
	return mat

func box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var obj := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	obj.mesh = mesh
	obj.material_override = matte(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

func build_world() -> void:
	world = Node3D.new()
	viewport.add_child(world)
	var env := WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color("182630")
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color("708794")
	env.environment.ambient_light_energy = 0.23
	world.add_child(env)
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 5.2
	camera.far = 30.0
	camera.position = Vector3(5.3, 5.1, 8.8)
	world.add_child(camera)
	camera.look_at(Vector3(0.0, 1.1, 0.0))
	camera.current = true
	# A single plane removes near-coplanar mesh lines from the shadow experiment.
	var floor_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(7.0, 6.0)
	floor_mesh.mesh = plane
	var floor_mat := ShaderMaterial.new()
	floor_mat.shader = load("res://grid_floor.gdshader")
	floor_mesh.material_override = floor_mat
	floor_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	world.add_child(floor_mesh)
	card = MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(2.4, 3.2)
	card.mesh = quad
	card.position = Vector3(0, 1.66, 0)
	material = ShaderMaterial.new()
	material.shader = load("res://pixel_card.gdshader")
	material.set_shader_parameter("color_map", diffuse)
	material.set_shader_parameter("normal_map", normals)
	card.material_override = material
	card.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_DOUBLE_SIDED
	world.add_child(card)
	# This box is actual depth geometry; its diagonal shadow can fall on the card.
	blocker = box(world, Vector3(-0.85, 2.6, 0.85), Vector3(0.16, 0.18, 1.45), Color("534139"))
	box(world, Vector3(1.6, 0.38, -0.7), Vector3(0.5, 0.76, 0.5), Color("8a8070"))
	key_light = DirectionalLight3D.new()
	key_light.position = Vector3(-3.0, 5.0, 4.0)
	world.add_child(key_light)
	key_light.look_at(Vector3.ZERO)
	key_light.light_energy = 1.0
	key_light.shadow_enabled = true
	key_light.directional_shadow_max_distance = 30.0
	key_light.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	key_light.shadow_bias = 0.1
	key_light.shadow_normal_bias = 2.0
	fill_light = OmniLight3D.new()
	fill_light.position = Vector3(2.3, 1.8, 2.3)
	fill_light.omni_range = 5.5
	fill_light.light_energy = 0.85
	fill_light.light_color = Color("ed9d5c")
	fill_light.shadow_enabled = false
	world.add_child(fill_light)

func build_canvas() -> void:
	canvas = Node2D.new()
	viewport.add_child(canvas)
	var bg := ColorRect.new()
	bg.size = Vector2(480, 272)
	bg.color = Color("243b49")
	bg.light_mask = 2
	canvas.add_child(bg)
	var modulate := CanvasModulate.new()
	modulate.color = Color(0.28, 0.32, 0.38)
	canvas.add_child(modulate)
	canvas_texture = CanvasTexture.new()
	canvas_texture.diffuse_texture = diffuse
	canvas_texture.normal_texture = normals
	canvas_texture.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite_2d = Sprite2D.new()
	sprite_2d.texture = canvas_texture
	sprite_2d.position = Vector2(240, 146)
	sprite_2d.scale = Vector2(6, 6)
	canvas.add_child(sprite_2d)
	var gradient := Gradient.new()
	gradient.colors = PackedColorArray([Color.WHITE, Color(1, 1, 1, 0)])
	var falloff := GradientTexture2D.new()
	falloff.width = 256
	falloff.height = 256
	falloff.gradient = gradient
	falloff.fill = GradientTexture2D.FILL_RADIAL
	falloff.fill_from = Vector2(0.5, 0.5)
	falloff.fill_to = Vector2(1.0, 0.5)
	light_2d = PointLight2D.new()
	light_2d.texture = falloff
	light_2d.texture_scale = 2.0
	light_2d.position = Vector2(160, 72)
	light_2d.energy = 1.8
	light_2d.height = lamp_height
	light_2d.range_item_cull_mask = 1
	canvas.add_child(light_2d)
	var marker := Polygon2D.new()
	marker.polygon = PackedVector2Array([Vector2(-3, -3), Vector2(3, -3), Vector2(3, 3), Vector2(-3, 3)])
	marker.position = light_2d.position
	marker.color = Color("ffc780")
	marker.light_mask = 2
	var unlit := CanvasItemMaterial.new()
	unlit.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	marker.material = unlit
	canvas.add_child(marker)
	var title := label_at("CanvasTexture: virtual light direction only", Vector2(16, 12), 13, canvas)
	title.light_mask = 2
	title.material = unlit
	var note := label_at("No 3D depth, silhouette extrusion or cast shadow", Vector2(16, 250), 12, canvas)
	note.light_mask = 2
	note.material = unlit

func apply_state() -> void:
	world.visible = not page_2d
	canvas.visible = page_2d
	material.set_shader_parameter("normal_mode", normal_mode)
	material.set_shader_parameter("clip_alpha", clip_alpha)
	key_light.shadow_enabled = shadows
	key_light.light_color = Color("dce8ed")
	fill_light.light_color = Color("f5aa69") if warm else Color("71b5fa")
	light_2d.color = fill_light.light_color
	light_2d.height = lamp_height
	canvas_texture.normal_texture = flat_normals if normal_mode == 0 else normals
	var modes := ["FLAT NORMAL", "OPENGL +Y NORMAL", "WRONG GREEN (negative control)"]
	heading.text = ("2D CANVAS  |  " if page_2d else "3D PIXEL CARD  |  ") + modes[normal_mode]
	if page_2d:
		detail.text = "PointLight2D height = %.0f canvas pixels | sprite scale 6 | fixed image, no geometry displacement" % lamp_height
	else:
		detail.text = "Tangent space | clip %s | shadow %s | local lamp %s | orthographic 5.2 world units" % [clip_alpha, shadows, "warm" if warm else "cool"]

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():
		return
	if event is InputEventKey:
		match event.keycode:
			KEY_1: page_2d = false
			KEY_2: page_2d = true; normal_mode = mini(normal_mode, 1)
			KEY_N: normal_mode = (normal_mode + 1) % (2 if page_2d else 3)
			KEY_C: clip_alpha = not clip_alpha
			KEY_S: shadows = not shadows
			KEY_L: warm = not warm
			KEY_H: lamp_height = 0.0 if lamp_height > 0.0 else 80.0
		apply_state()

func settle(frames: int = 5) -> void:
	for i in range(frames):
		await get_tree().process_frame

func capture(tag: String) -> void:
	apply_state()
	await settle()
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	assert(not img.is_empty())
	assert(img.save_png(out + tag + ".png") == OK)
	var raw := viewport.get_texture().get_image()
	assert(raw.save_png(out + tag + "_view.png") == OK)
	captures.append({"name": tag, "time_usec": Time.get_ticks_usec(), "normal_mode": normal_mode, "normal_space": "tangent OpenGL +X +Y +Z; image +y down converted during derivative", "alpha_clip": clip_alpha, "shadows": shadows, "warm_local_light": warm, "page_2d": page_2d, "pointlight2d_height_pixels": lamp_height if page_2d else null, "camera_position": [camera.position.x, camera.position.y, camera.position.z], "camera_projection": "orthographic", "camera_size_world_units": camera.size, "internal_viewport": [viewport.size.x, viewport.size.y], "window_pixels": [img.get_width(), img.get_height()], "shadow_bias": key_light.shadow_bias, "shadow_normal_bias": key_light.shadow_normal_bias, "shadow_mode": key_light.directional_shadow_mode, "key_light_position": [key_light.position.x, key_light.position.y, key_light.position.z], "local_light_position": [fill_light.position.x, fill_light.position.y, fill_light.position.z], "local_light_energy": fill_light.light_energy})

func measure(mode: int, index: int) -> void:
	normal_mode = mode
	apply_state()
	await settle(8)
	var samples: Array[float] = []
	var start := Time.get_ticks_usec()
	var previous := start
	while Time.get_ticks_usec() - start < 2500000:
		await get_tree().process_frame
		var now := Time.get_ticks_usec()
		samples.append(float(now - previous) / 1000.0)
		previous = now
	samples.sort()
	measurements.append({"index": index, "normal_mode": mode, "frames": samples.size(), "duration_ms": (previous - start) / 1000.0, "median_ms": samples[int(samples.size() * 0.5)], "p95_ms": samples[mini(samples.size() - 1, int(samples.size() * 0.95))], "draw_calls": Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), "static_memory_bytes": OS.get_static_memory_usage()})

func run_probe() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Visual probe requires a real graphics renderer; headless is parse-only.")
		get_tree().quit(2)
		return
	out = "res://qa/run_" + str(int(Time.get_unix_time_from_system())) + "/"
	DirAccess.make_dir_recursive_absolute(out)
	await settle(10)
	if OS.get_cmdline_user_args().has("--bias-scan"):
		key_light.shadow_normal_bias = 0.1
		for bias in [0.0, 0.0005, 0.002, 0.01, 0.04, 0.1]:
			key_light.shadow_bias = bias
			await capture("bias_%s" % str(bias).replace(".", "_"))
		var scan := FileAccess.open(out + "bias_scan.json", FileAccess.WRITE)
		scan.store_string(JSON.stringify({"captures": captures, "adapter": RenderingServer.get_video_adapter_name(), "camera_far": camera.far, "shadow_max_distance": key_light.directional_shadow_max_distance}, "  "))
		print("PIXEL_LIGHTING_BIAS_SCAN_COMPLETE ", out)
		get_tree().quit()
		return
	for mode in range(3):
		normal_mode = mode
		await capture(["01_flat", "02_correct_normal", "03_wrong_green"][mode])
	normal_mode = 1
	clip_alpha = false
	await capture("04_no_alpha_clip")
	clip_alpha = true
	shadows = false
	await capture("05_no_shadow")
	shadows = true
	warm = false
	await capture("06_cool_local_light")
	warm = true
	blocker.visible = false
	await capture("07_without_blocker")
	blocker.visible = true
	for i in range(4):
		await measure(i % 2, i)
	normal_mode = 1
	await capture("08_static_repeat")
	page_2d = true
	lamp_height = 0.0
	await capture("09_canvas_height_0")
	lamp_height = 80.0
	await capture("10_canvas_height_80")
	normal_mode = 0
	await capture("11_canvas_flat_height_80")
	var report := {"engine": Engine.get_version_info().string, "renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name(), "display": DisplayServer.get_name(), "captures": captures, "performance": measurements, "claims": "Real native Compatibility screenshots. No browser/WebGL2 runtime test. Cloud llvmpipe timings are not user device estimates.", "shader_sha256": FileAccess.get_sha256("res://pixel_card.gdshader"), "script_sha256": FileAccess.get_sha256("res://lab.gd")}
	var file := FileAccess.open(out + "probe.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "  "))
	print("PIXEL_LIGHTING_PROBE_COMPLETE ", out)
	get_tree().quit()
