"""Optional offline evidence check. Requires Pillow; does not render or edit images."""
import argparse
import json
from pathlib import Path
from PIL import Image, ImageChops

parser = argparse.ArgumentParser()
parser.add_argument('run_directory', type=Path)
args = parser.parse_args()
root = args.run_directory

def compare(a, b, roi=None):
    first = Image.open(root / (a + '_view.png')).convert('RGB')
    second = Image.open(root / (b + '_view.png')).convert('RGB')
    if roi:
        first, second = first.crop(roi), second.crop(roi)
    difference = ImageChops.difference(first, second)
    values = list(difference.getdata())
    return {
        'a': a, 'b': b, 'roi_xyxy': roi,
        'pixels': len(values),
        'changed_pixels': sum(max(pixel) > 0 for pixel in values),
        'max_channel_delta': max(max(pixel) for pixel in values),
        'mean_absolute_channel_delta': sum(sum(pixel) for pixel in values) / (3 * len(values)),
    }

pairs = [
    ('01_flat', '02_correct_normal'),
    ('02_correct_normal', '03_wrong_green'),
    ('02_correct_normal', '04_no_alpha_clip'),
    ('02_correct_normal', '05_no_shadow'),
    ('02_correct_normal', '06_cool_local_light'),
    ('02_correct_normal', '07_without_blocker'),
    ('02_correct_normal', '08_static_repeat'),
    ('09_canvas_height_0', '10_canvas_height_80'),
    ('10_canvas_height_80', '11_canvas_flat_height_80'),
]
results = [compare(a, b) for a, b in pairs]
assert results[6]['changed_pixels'] == 0, 'Fixed-time static repeat differs.'
for i, item in enumerate(results):
    if i != 6:
        assert item['changed_pixels'] > 0, f"No observed effect: {item['a']} / {item['b']}"

report = {
    'comparisons': results,
    'scope': 'Pixel differences establish an observable toggle, not artistic correctness; inspect the actual PNGs.',
    'static_repeat_exact': True,
    'capture_size': list(Image.open(root / '02_correct_normal.png').size),
    'internal_view_size': list(Image.open(root / '02_correct_normal_view.png').size),
}
(root / 'pixel_validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
