extends SceneTree
# CLI entry point: godot --path . --script res://run_probe.gd -- --probe
func _initialize() -> void:
	root.add_child(load("res://main.tscn").instantiate())
