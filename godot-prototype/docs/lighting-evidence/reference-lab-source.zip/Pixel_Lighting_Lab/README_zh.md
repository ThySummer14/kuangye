# 像素邮牌光照实验

2026-10-08 更新：新增不规则拱门遮挡的 A/B/C 实验，见 OCCLUSION_RESULT_zh.md。旧光照场景保持原样；在 Godot 中打开 occlusion.tscn 即可运行新场景，或执行 `godot --path . res://occlusion.tscn`。自动取证参数为 `-- --probe-occlusion`。

这是给暮邮谷与旷野准备的独立 Godot 4.6 实验室，研究像素精灵的法线、alpha 裁剪、投受影和局部灯色。代码、24×32 像素邮牌、数学生成的高度与法线图均为本实验原创，采用 MIT 许可；没有收录 Minecraft 光影包源码。

## 运行

用 Godot 4.6 打开 project.godot，按 F6/F5 运行。保持 Compatibility renderer。桌面窗口为 960×640，实验视图是 480×272，经 nearest 放大 2 倍。打开编辑器时会正常导入项目资源；不需要登录、游戏账号、mod、插件或额外依赖。

命令行也可执行：

```sh
godot --path .
```

自动取证模式保存图像、相机与灯参数、时间戳和帧时间，再退出：

```sh
godot --path . --audio-driver Dummy --disable-vsync -- --probe
```

自动模式必须用真实图形 renderer，headless 仅可检查语法，不能作为视觉验收。图像输出到 qa/run_时间戳。没有内置自动下载或网络访问。

## 按键

| 按键 | 用途 |
| --- | --- |
| 1 / 2 | 切换 3D 与纯 2D Canvas 页面 |
| N | 3D：平法线、正确 OpenGL 法线、故意翻转绿通道；2D：平法线、正确法线 |
| C | 3D alpha 裁剪开关，观察透明角与上方镂空 |
| S | 3D 主灯阴影开关 |
| L | 局部灯切换暖色/冷色，保持位置和能量 |
| H | 2D PointLight2D.height 切换 0 / 80 canvas 像素 |

## 该比较什么

3D 页是一张固定在真实 3D 世界里的 QuadMesh 像素卡片，使用正交相机、切线空间 NORMAL_MAP 和二值 alpha discard。法线来自独立的高度函数，不从彩色像素亮度推算。色彩图与法线图尺寸一致，纹理不做平滑插值。角点和镂空用同一 alpha 判定参与颜色及阴影 pass。

高度函数只用于生成表面法线，没有改动顶点。它不会让轮廓鼓起、产生厚度、改变碰撞或使投影随微小凸起变化。横在牌前的棕色条才是真实三维遮挡物。默认不使用 billboard，避免相机朝向与投影方向混杂。

3D 法线采用 Godot 的 OpenGL X+、Y+、Z+ 约定。图像行号向下增加，所以在求高度 Y 导数时显式转到向上的表面坐标。不能把切线法线直接赋给世界空间法线，也不能按直觉随便翻绿通道。错绿通道是负例，不是另一种可选艺术风格。

2D 页使用 CanvasTexture、Sprite2D、CanvasModulate 与 PointLight2D，height 单位为当前 canvas 像素；Sprite 放大六倍。该页没有 3D 深度、厚度或几何投影，也没有自动从 alpha 生成 LightOccluder2D。灯高改变的是虚拟入射方向。CanvasTexture 不可直接用于 Sprite3D。

## 预渲染精灵如何用这个结果

如果以后用 3D 模型预渲染人物帧，diffuse 应尽量保存不含固定主灯烘焙阴影的底色，并同时输出与相机/帧布局一致的法线通道。已经烘入底色的明暗不会被实时灯正确撤销，再叠实时法线可能出现双重阴影。每帧仍是一张卡片；要真实厚度遮挡，应保留低模代理、分层几何或另外设计深度数据，不能靠法线图自动获得。

本实验没有用预渲染人物，也没有声称已经验证角色整套动画。它提供的是一个可复现的小样，先校正坐标、阴影、采样与颜色，再决定是否推广。

## 验证边界与失败记录

本轮已在云端原生 Compatibility 真正运行，并保留每轮实际结果。没有浏览器 WebGL2 实测时，不以桌面截图代替浏览器通过；llvmpipe 软件渲染的帧时也不能预测玩家硬件速度。最终实测数据见随包 RESULT_zh.md 与 qa 中的 JSON。

初次语法检查发现不存在的 Environment 枚举，已移除；首次检查的编辑器缓存路径不可写，后续验证改用实验目录内的独立缓存、配置和数据目录。首次程序退出码为 0 仍存在解析错误，因此没有将它计作通过。保留验证失败说明，是为了区分实际修复与未经检查的成功声明。

## 来源与许可边界

- [Godot CanvasTexture](https://docs.godotengine.org/en/4.6/classes/class_canvastexture.html)：只用于 2D，法线坐标约定。
- [Godot Spatial shader](https://docs.godotengine.org/en/4.6/tutorials/shaders/shader_reference/spatial_shader.html)：NORMAL_MAP 属于切线空间；alpha 与透明管线。
- [Godot StandardMaterial3D](https://docs.godotengine.org/en/4.6/tutorials/3d/standard_material_3d.html)：法线不改变几何，OpenGL 约定，height 的视觉假象。
- [SpriteBase3D](https://docs.godotengine.org/en/4.6/classes/class_spritebase3d.html)：alpha cut、双面和 billboard 投影限制。
- [PointLight2D](https://docs.godotengine.org/en/4.6/classes/class_pointlight2d.html)：height 单位与作用。
- [Godot renderer 对照](https://docs.godotengine.org/en/4.6/tutorials/rendering/renderers.html)、[Web 导出](https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_web.html)：Compatibility 与 Web 路线。

此前研究的 Complementary r5.9.3、MakeUp 9.5g、Photon v1.3b 提供的是问题观察：无时间积累时保持采样稳定；采样越过有效水域要拒绝；泡沫覆盖与镜面反射要协同。这里没有复制它们的代码、资源或缓冲编号。特别是 Complementary 与 Photon 的自定义许可，不自动覆盖向 Godot 游戏摘取代码。MakeUp 的 LGPL 也不是无条件免署名。上面三条思想只用于下一步独立水面小样的设计，本实验自身没有实现水或 SSR。

可选离线像素比对脚本 analyze_capture.py 需要 Python 与 Pillow，它只读原始截图并输出 JSON，不修改图像。运行 Godot 工程本身不需要这些分析依赖。
